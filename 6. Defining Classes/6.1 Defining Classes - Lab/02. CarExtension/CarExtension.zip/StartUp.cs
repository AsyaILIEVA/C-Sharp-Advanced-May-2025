﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            var car = new Car
            {
                Make = "BMW",
                Model = "M850i",
                Year = 2021,
                FuelQuantity = 100,
                FuelConsumption = 13.5

            };
            
        }
    }
}